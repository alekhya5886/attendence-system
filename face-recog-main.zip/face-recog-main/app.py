from flask import Flask, Response, jsonify, redirect, render_template, request, url_for
import mysql.connector
from datetime import datetime
import cv2
import face_recognition
import numpy as np
import os

app = Flask(__name__)

# Load and encode known faces
known_face_encodings = []
known_face_names = []

# Load images and create encodings (put your images in a folder named "known_faces")
known_faces_dir = "known_faces"
for filename in os.listdir(known_faces_dir):
    if filename.endswith((".jpg", ".png")):
        img_path = os.path.join(known_faces_dir, filename)
        image = face_recognition.load_image_file(img_path)
        encodings = face_recognition.face_encodings(image)
        if encodings:
            encoding = encodings[0]
            known_face_encodings.append(encoding)
            known_face_names.append(os.path.splitext(filename)[0])  # Use the file name (without extension) as the person's name
        else:
            print(f"No faces found in {filename}")

# Initialize video capture
video_capture = cv2.VideoCapture(0)

# Check if the webcam is opened correctly
if not video_capture.isOpened():
    raise IOError("Cannot open webcam")

# Function to fetch student names from database
def fetch_student_names():
    try:
        # Connect to MySQL
        conn = mysql.connector.connect(
            host="localhost",
            user="root",
            password="",  # Replace with your MySQL password
            database="attendance_db"
        )
        cursor = conn.cursor()
        
        # Fetch students' registration numbers and names
        cursor.execute("SELECT registration_number, name FROM students")
        students = cursor.fetchall()
        
        cursor.close()
        conn.close()
        
        return students
    
    except mysql.connector.Error as e:
        print(f"Error fetching data from MySQL: {e}")
        return []

# Function to detect and recognize faces
def detect_and_recognize_faces(frame):
    rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    
    # Detect faces using face_recognition
    face_locations = face_recognition.face_locations(rgb_frame)
    face_encodings = face_recognition.face_encodings(rgb_frame, face_locations)

    recognized_names = []

    for face_encoding, face_location in zip(face_encodings, face_locations):
        # Check accuracy of recognized faces
        matches = face_recognition.compare_faces(known_face_encodings, face_encoding)
        face_distances = face_recognition.face_distance(known_face_encodings, face_encoding)
        
        name = "Unknown"
        best_match_index = np.argmin(face_distances)
        
        if matches[best_match_index] and face_distances[best_match_index] < 0.6:  # Adjust threshold as needed
            name = known_face_names[best_match_index]
        
        # Draw a rectangle around the face
        top, right, bottom, left = face_location
        cv2.rectangle(frame, (left, top), (right, bottom), (255, 255, 0), 2)
        
        # Draw the name below the face
        cv2.putText(frame, name, (left, bottom + 20), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1, cv2.LINE_AA)

        # If recognized with high accuracy, add to recognized names
        if name != "Unknown":
            recognized_names.append(name)
    
    return frame, recognized_names

# Route to display index page
@app.route('/')
def index():
    students = fetch_student_names()
    return render_template('index.html', students=students)

# Route to save attendance data
@app.route('/save_attendance', methods=['POST'])
def save_attendance():
    try:
        # Get selected students' registration numbers from form
        attendance_list = request.form.getlist('students')
        date = datetime.now().date()
        
        print(f"Selected students: {attendance_list}")  # Debug statement
        
        # Connect to MySQL
        conn = mysql.connector.connect(
            host="localhost",
            user="root",
            password="",  # Replace with your MySQL password
            database="attendance_db"
        )
        cursor = conn.cursor()
        
        # Insert attendance data into the attendance table
        for reg_no in attendance_list:
            cursor.execute("SELECT name FROM students WHERE registration_number = %s", (reg_no,))
            student_name = cursor.fetchone()[0]
            cursor.execute("INSERT INTO attendance (registration_number, name, date) VALUES (%s, %s, %s)", (reg_no, student_name, date))
        
        conn.commit()
        cursor.close()
        conn.close()

        print("Attendance saved successfully")  # Debug statement
        return redirect(url_for('thank_you'))

    except mysql.connector.Error as e:
        print(f"Error saving attendance data to MySQL: {e}")
        return render_template('error.html', message='Error saving attendance data to MySQL')

    except Exception as e:
        print(f"Exception occurred: {e}")
        return render_template('error.html', message='Exception occurred')

# Route for thank you page
@app.route('/thank_you')
def thank_you():
    return render_template('thank_you.html')

# Video feed endpoint for face recognition
def gen_frames():
    while True:
        success, frame = video_capture.read()
        if not success:
            print("Failed to read frame from webcam")
            break
        else:
            annotated_frame, recognized_names = detect_and_recognize_faces(frame)
            ret, buffer = cv2.imencode('.jpg', annotated_frame)
            frame = buffer.tobytes()
            yield (b'--frame\r\n'
                   b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')

# Route for video feed with face recognition
@app.route('/video_feed')
def video_feed():
    return Response(gen_frames(), mimetype='multipart/x-mixed-replace; boundary=frame')

# Route to fetch recognized students
@app.route('/recognized_students')
def recognized_students():
    _, recognized_names = detect_and_recognize_faces(video_capture.read()[1])  # Use current webcam frame
    return jsonify({'recognized_students': recognized_names})

# Error handling route
@app.route('/error')
def error():
    return render_template('error.html', message='An unexpected error occurred.')

if __name__ == "__main__":
    app.run(debug=True)
