import pandas as pd
import mysql.connector

# Read the Excel file
df = pd.read_excel('students.xlsx')

# Print the first few rows to verify column names
print(df.head())

# Connect to MySQL
conn = mysql.connector.connect(
    host="localhost",
    user="root",
    password="",
    database="attendance_db"
)

cursor = conn.cursor()

# Insert data into the students table
for index, row in df.iterrows():
    cursor.execute("INSERT INTO students (registration_number, name) VALUES (%s, %s)", (row['RegNo'], row['Name']))

conn.commit()
cursor.close()
conn.close()
